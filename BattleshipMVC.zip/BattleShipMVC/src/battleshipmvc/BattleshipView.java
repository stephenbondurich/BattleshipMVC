package battleshipmvc;

/**
 * @author Stephen Bondurich
 * Dec 4, 2018
 *
 * 
 */
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import acm.graphics.GLabel;
import acm.graphics.GObject;
import acm.graphics.GPoint;
import acm.graphics.GRect;
import acm.graphics.GRectangle;
import acm.gui.IntField;
import acm.program.GraphicsProgram;


@SuppressWarnings("serial")
public class BattleshipView extends GraphicsProgram {

/*
 * 
 * The view for a game of battleship. In this implementation, only one player can play at a time.
 * Ideally, two windows would be running, and the two players would set up ships on their own 
 * windows, then take turns attacking the other's window.
 * Two-player functionality in one window coming soon, as well as an AI opponent.
 * 
 * Fun discovery: As one can see based on the above, Battleship is not the easiest game to play
 * using a single device :) 
 * 
 */
	
	BattleshipModel model;
	BattleshipController controller;
	
	final int SQUARESIZE = 50;
	private int viewHeight;
	private int viewWidth;
	
	
	private JButton newGameBtn;
	private JButton startGameBtn;
	private JButton randomShipBtn;
	
	private JLabel helperText;
	
	private MouseMotionListener myListener;
	
	public int getSQUARESIZE() {
		return SQUARESIZE;
	}

	private int xIncrement;
	private int yIncrement;
	private GRect[][] viewBoardArray;
	private ArrayList<GRect> yellowSpacesArrayList;
	private ArrayList<GRect> shipSpacesArrayList;
	
	public void init() {
		//here is our "main" method -  we give life to a model and a controller
		
		newGameBtn = new JButton("New game");
		startGameBtn = new JButton("Start Game");
		randomShipBtn = new JButton("Insert Random Ship");
		helperText = new JLabel("To add a ship, begin by selecting a square. Click Start Game if you are done.");
		yellowSpacesArrayList = new ArrayList<GRect>();
		shipSpacesArrayList = new ArrayList<GRect>();
		
		beginGame();
		controller.addListeners();
	
		
		viewHeight = SQUARESIZE * model.getBoardSize()+75;

		viewWidth = SQUARESIZE * model.getBoardSize();
		setSize(viewWidth, viewHeight);
		setBackground(Color.WHITE);
		
		add(randomShipBtn, SOUTH);
		add(startGameBtn, SOUTH);
		add(helperText, NORTH);
		add(newGameBtn, SOUTH);
	}

	public void beginGame() {
		removeAll();
		model = new BattleshipModel();
		controller = new BattleshipController(model, this);
		this.changeHelperTextClickStartPoint();
		yellowSpacesArrayList.clear();
	}
	
	public void drawCell(int row, int col) {
		int xpos = SQUARESIZE*row;
		int ypos = SQUARESIZE*col;
		GRect cell = new GRect(xpos, ypos, SQUARESIZE, SQUARESIZE);
		cell.setFillColor(Color.blue);
		cell.setFilled(true);
		viewBoardArray[row][col] = cell;
		add(cell);
		
				
	}
	
	
	public void add(GRect g) {
		super.add((GObject) g);
	}
	
	
	public void setViewBoardSize(int dimension) {
		viewBoardArray = new GRect[dimension][dimension];
	}
	
	public void setNotSelectedColor(int row, int col) {
		
		viewBoardArray[row][col].setFillColor(Color.BLUE);
		yellowSpacesArrayList.remove(viewBoardArray[row][col]);
		
	}
	public void setSelectedColor(int row, int col) {
		viewBoardArray[row][col].setFillColor(Color.RED);
	}
	
	public void setShipSelectedColor(int row, int col) {
		viewBoardArray[row][col].setFillColor(Color.GREEN);
	}
	
	public void setTempSelectedColor(int row, int col) {
		viewBoardArray[row][col].setFillColor(Color.YELLOW);
	}
	
	public void turnSpaceBlue(int row, int col) {
		viewBoardArray[row][col].setFillColor(Color.BLUE);
	}
	public void turnShipSpacesBlue() {
		Iterator iter = shipSpacesArrayList.iterator();
		
		while (iter.hasNext()) {
			GRect g = (GRect)iter.next();
			g.setFillColor(Color.BLUE);
		}
	}
	public void clearYellowSpaceList() {
		yellowSpacesArrayList.clear();
	}
	//also empties the arraylist
		public void turnYellowSpacesBlue() {
			
			Iterator iter = yellowSpacesArrayList.iterator();
			
			while (iter.hasNext()) {
				GRect g = (GRect)iter.next();
				g.setFillColor(Color.BLUE);
			}
		}
	public void colorCellsInBetween(int row1, int col1, int row2, int col2) {
		int truer1 = row1;
		int truec1 = col1;
		
		if (row1 == row2) {
			
			if(col1>col2) {
				int temp = col1;
				col1 = col2;
				col2 = temp;
			}
			
			for (int i = col1; i <= col2; i++) {
				setTempSelectedColor(row1, i);
				
				yellowSpacesArrayList.add(viewBoardArray[row1][i]);
				
				
			}
		}
		else if (col1 == col2) {
			
			if(row1>row2) {
				int temp = row1;
				row1 = row2;
				row2 = temp;
			}

			for (int i = row1; i <= row2; i++) {
				setTempSelectedColor(i, col1);
				
				yellowSpacesArrayList.add(viewBoardArray[i][col1]);
				
			}
		}
		else {
			System.out.println("Invalid ship");
			//for debugging
		}
		
		yellowSpacesArrayList.remove(viewBoardArray[truer1][truec1]);
	}
	
	public void colorRandomShip(int row1, int col1, int row2, int col2) {
	
		
		if (row1 == row2) {
			
			if(col1>col2) {
				int temp = col1;
				col1 = col2;
				col2 = temp;
			}
			
			for (int i = col1; i <= col2; i++) {
				setTempSelectedColor(row1, i);	
			}
		}
		else if (col1 == col2) {
			
			if(row1>row2) {
				int temp = row1;
				row1 = row2;
				row2 = temp;
			}

			for (int i = row1; i <= row2; i++) {
				setTempSelectedColor(i, col1);
				
				
			}
		}
		else {
			System.out.println("Invalid random ship");
		} //for debugging
		
	
	}
	
	public void addSpaceClickedListener(MouseListener m) {
		getGCanvas().addMouseListener(m);
	} 
	
	
	
	public void gameOverNotification() {
		removeAll();
		GLabel text = new GLabel("Game Over");
		add(text, getWidth()/2-text.getWidth()/2, getHeight()/2);
	}

	public void addNewGameListener(ActionListener a) {
	
		newGameBtn.addActionListener(a);
	}
	
	public void addRandomShipListener(ActionListener a) {
		randomShipBtn.addActionListener(a);
	}
	
	public void addShipMotionListener(MouseMotionListener m) {
		myListener = m;
		getGCanvas().addMouseMotionListener(myListener);
	} 
	
	public void removeMotionListener() {
		
		getGCanvas().removeMouseMotionListener(myListener);
	}
	
	public void addStartGameListener(ActionListener a) {
		startGameBtn.addActionListener(a);
	}
	
	public void addToShipSpacesArrayList(int row, int col) {
		shipSpacesArrayList.add(viewBoardArray[row][col]);
		
	}
	
	public boolean isYellowListEmpty() {
		return yellowSpacesArrayList.isEmpty();
	}
	
	
	

	
	public void changeHelperTextClickEndPoint() {
		helperText.setText("Now, click the square where you would like your ship to end");
	}
	public void changeHelperTextClickStartPoint() {
		helperText.setText("To add a ship, begin by selecting a square");
	}
	
	public void changeHelperTextGameBegan() {
		helperText.setText("Click on a square!");
	}
	
	public void hitNotification() {
		helperText.setText("You hit a ship!");
	}
	
	public void missNotification() {
		helperText.setText("You missed!");
	}
	public void changeHelperTextNoShips() {
		helperText.setText("You need to add at least one ship before you begin!");
	}

	public void setHelperTextNoDiagonals() {
		// TODO Auto-generated method stub
		helperText.setText("You cannot create a diagonal ship! Try selecting the space again.");
		
	}

	public void setHelperTextNoOverlap() {
		// TODO Auto-generated method stub
		helperText.setText("No overlapping ships allowed! Try selecting the space again");
	}
	
	public void setHelperTextAlreadyShip() {
		helperText.setText("That space is already part of another ship! Try a different one");
	}
	
}



