package battleshipmvc;

import acm.graphics.GCompound;

/**
 * @author Stephen Bondurich
 *
 *         The logic of this program does not care about ship objects
 *         themselves, it only cares about spaces that occupy ships. Indeed,
 *         just as a player cannot know if they have successfully sunk a ship
 *         until both ends of a ship-line are "misses", the model cannot tell if
 *         a ship has been sunk; it only knows when all the ship spaces have
 *         been sunk.
 */
public class Boardspace extends GCompound {

	private boolean alreadySelected;
	// records if this space has been chosen by the player, regardless of hit/miss
	private boolean isShip;
	// determines if this space contains a ship component

	private boolean opponentSpace = false;

	public Boardspace(boolean status) {
		opponentSpace = status;
	}

	public Boardspace() {
		alreadySelected = false;
		isShip = false;
	}

	public boolean isAlreadySelected() {
		return alreadySelected;
	}

	public void setSelected() {
		this.alreadySelected = true;
	}

	public boolean isShip() {
		return isShip;
	}

	public void setShip(boolean b) {
		this.isShip = b;
	}

}
