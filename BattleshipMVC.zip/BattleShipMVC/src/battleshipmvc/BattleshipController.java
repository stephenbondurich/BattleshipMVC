package battleshipmvc;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import acm.graphics.GObject;
import acm.graphics.GPoint;
import acm.graphics.GRect;

/**
 * @author Stephen Bondurich
 * Controller for communicaiton between the view and model
 *
 * 
 */
public class BattleshipController {
	private BattleshipModel model;
	private BattleshipView view;
	
	
	
	private GRect firstCell=null;
	private GPoint startPoint=null;
	private GRect lastCell=null;
	private GPoint endPoint=null;
	
	private GRect farCell;
	private GPoint farPointX;
	private GPoint farPointY;
	private String direction = "";
	private String lastDirection = "";
	private boolean shipInProgress = false;
	
	
	private boolean gameOn = false;

	public BattleshipController(BattleshipModel m, BattleshipView v) {
		this.model = m;
		view = v;
		view.setViewBoardSize(m.getBoardSize());
		
		fillBoard();

	}
	
	
	private void fillBoard() {
		for (int row = 0; row < 10; row++) {
			for (int col = 0; col < 10; col++) {
				view.drawCell(row, col);		
			}
		}
	}
	
	public void addListeners()
	{
		view.addNewGameListener(new newGameListener());
		view.addStartGameListener(new startGameListener());
		view.addRandomShipListener(new randomShipBtnListener());
		view.addSpaceClickedListener(new spaceClickedListener());
	}
	
	class newGameListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			
			view.beginGame();
			model.createNewGame();
			gameOn = false;
			farPointX = null;
			farPointY = null;
			view.clearYellowSpaceList();
			view.removeMotionListener();

		}
	}
	
	
	class randomShipBtnListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
		if (gameOn==false) {	
			boolean success = false;
			while(!success)
			{
				int startRow = (int)(Math.random() * model.getBoardSize());
				int startCol = (int)(Math.random() * model.getBoardSize());
				int endCol, endRow;
				if(!model.getBoardspace(startRow, startCol).isShip()) 
				{
					double rand = Math.random();
					if (rand <0.5) {// we make the ship go vertical
						endCol = (int)(Math.random() * model.getBoardSize());
						endRow = startRow;
					}
					else //we choose to make it go horizontal
					{
						endRow = (int)(Math.random() * model.getBoardSize());
						endCol = startCol;
					}
					
					if (model.canShipBeInserted(startRow, startCol, endRow, endCol)) {
						try {
							model.addShip(startRow, startCol, endRow, endCol);
							view.colorRandomShip(startRow, startCol, endRow, endCol);
							success = true;
						}
						catch (Exception e1){
							System.out.println(e1.getMessage());
						}
					}
				}
			}
		}
		}
	}
	
	class shipSetMotionListener implements MouseMotionListener{

		@Override
		public void mouseDragged(MouseEvent e) {
			
		}

		@Override
		public void mouseMoved(MouseEvent e) {
			if (view.getElementAt(e.getX(), e.getY()) instanceof GRect && firstCell!=null) {
				GRect cell = (GRect)view.getElementAt(e.getX(), e.getY());
				GPoint currentPoint = cell.getLocation();
	
				
				if (currentPoint.getX() == startPoint.getX()) {
					//we're not at a diagonal
					//we're in the same vertical line
					
					
					if(currentPoint.getY()>startPoint.getY()) {
						direction = "below";
					}
					if(currentPoint.getY()<startPoint.getY()) {
						direction = "above";
					}
					
			
					//figure out how to make it recognize the case of going back to origin depends on direction it comes from
					if(direction.equals(lastDirection)){
						if (model.canShipBeInserted(getXForArray(startPoint), getYForArray(startPoint),
								getXForArray(currentPoint), getYForArray(currentPoint))){
							if(Math.abs(currentPoint.getY()-startPoint.getY())>=Math.abs(farPointY.getY()- startPoint.getY()))
							{
								
								farPointY = currentPoint;
								view.colorCellsInBetween(getXForArray(startPoint), getYForArray(startPoint),
										getXForArray(currentPoint), getYForArray(currentPoint));
							}
							else
							{
								
								view.setNotSelectedColor(getXForArray(farPointY), getYForArray(farPointY));
								//and remove it from the list
								farPointY = currentPoint;
							}
								
						
								
							}
					}
					else {//this means we switched directions....
						lastDirection = direction.toString();
						view.turnYellowSpacesBlue();
					}
					
				}
				else if (currentPoint.getY() == startPoint.getY())
				//we are in same horizontal line
				{
					if(currentPoint.getX()>startPoint.getX()) {
						direction = "right";
					}
					if(currentPoint.getX()<startPoint.getX()) {
						direction = "left";
					}
	
					
					if(direction.equals(lastDirection)){
					
						if (model.canShipBeInserted(getXForArray(startPoint), getYForArray(startPoint),
								getXForArray(currentPoint), getYForArray(currentPoint))){
								
								if(Math.abs(currentPoint.getX()-startPoint.getX())>=Math.abs(farPointX.getX()- startPoint.getX()))
								{
									
									farPointX= currentPoint;
									view.colorCellsInBetween(getXForArray(startPoint), getYForArray(startPoint),
											getXForArray(currentPoint), getYForArray(currentPoint));
								}
								else
								{
									
									view.setNotSelectedColor(getXForArray(farPointX), getYForArray(farPointX));
									//and remove it from the list
									farPointX = currentPoint;
							}
								
								
						}
						
					}
					else {//this means we switched directions....
						lastDirection = direction.toString();
						view.turnYellowSpacesBlue();
					}
				}
				else // this is code for if we go on a diagonal, which is useful in knowing if we hop down the same line...
				{
				view.turnYellowSpacesBlue();
				
			}
	
			
			}
		
			
		}
		
	}
	
	

	
	class startGameListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			
			if(model.getTotalShips() > 0 && !shipInProgress) {
				view.changeHelperTextGameBegan();
				
				
				//turn all spaces blue
				for (int i = 0; i < model.getBoardSize(); i++) {
					for (int j =  0; j <model.getBoardSize(); j++) {
						if(model.getBoardspace(i, j).isShip()) {
							view.turnSpaceBlue(i, j);
						}
					}
				}
				
				
				gameOn = true;
			}
			else {
				view.changeHelperTextNoShips();
			}
			
		}
	}
	
	
	class spaceClickedListener implements MouseListener{

		@Override
		public void mouseClicked(MouseEvent e) {
			
			if (gameOn) {
				if (view.getElementAt(e.getX(), e.getY()) instanceof GRect) {
					GRect cell = (GRect)view.getElementAt(e.getX(), e.getY());
					GPoint point = cell.getLocation();
					
					model.selectSpace(getXForArray(point), getYForArray(point));
					
					if (model.getBoardspace(getXForArray(point), getYForArray(point)).isShip()) {
						view.setShipSelectedColor(getXForArray(point), getYForArray(point));
						view.hitNotification();
					}
					else {
						view.setSelectedColor(getXForArray(point), getYForArray(point));
						view.missNotification();
					}
					
					checkGameOver();
					}
			} 
			
			
			else { //if gameOn is false - this code gets run when you choose a space to set a ship
				if (view.getElementAt(e.getX(), e.getY()) instanceof GRect) {
					GRect cell = (GRect)view.getElementAt(e.getX(), e.getY());
					GPoint point = cell.getLocation();
					
					if (model.getBoardspace(getXForArray(point), getYForArray(point)).isShip()) {
						System.out.println("invalid selection; space already taken");
						view.setHelperTextAlreadyShip();
						return;
					}//short circuit right here if the space has already been occupied as a ship
					
					
					if (view.getElementAt(e.getX(), e.getY()) instanceof GRect) {
						if(firstCell == null) {
							shipInProgress = true;
							firstCell = (GRect)view.getElementAt(e.getX(), e.getY());
							startPoint = firstCell.getLocation();
							farCell = firstCell;
							farPointX = startPoint;
							farPointY = startPoint;
							
							view.setTempSelectedColor(getXForArray(startPoint), getYForArray(startPoint));
							
							view.changeHelperTextClickEndPoint();
							
							view.addShipMotionListener(new shipSetMotionListener());
						}
						else { //so, the first cell has already been chosen
							lastCell = (GRect)view.getElementAt(e.getX(), e.getY());
							endPoint = lastCell.getLocation();
							
							try {
								model.addShip(getXForArray(startPoint), getYForArray(startPoint),
										getXForArray(endPoint), getYForArray(endPoint));
								view.changeHelperTextClickStartPoint();
								
								view.setTempSelectedColor(getXForArray(endPoint), getYForArray(endPoint));
								view.removeMotionListener();
								view.clearYellowSpaceList();
								shipInProgress = false;
								firstCell = null;
							} catch (Exception e1) {
								
								//in order to run this if statement, all possible exceptions must have a msg defined!
								if(e1.getMessage().equals("No overlap allowed!")) {
									view.setHelperTextNoOverlap();
								}
								else {
								view.setHelperTextNoDiagonals();
								}
							}
						}					
						
					}
			}
			}
			
		}
		
		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	}
	
	
	
	
	private int getXForArray(GPoint point) {
		return (int)(point.getX()/view.getSQUARESIZE());
	}
	
	private int getYForArray(GPoint point) {
		return (int)(point.getY()/view.getSQUARESIZE());
	}
	private void checkGameOver() {
		if (gameOn){
				if(model.isGameOver()) {
					
					view.gameOverNotification();
			}
		}
	}
	
	
	
}


