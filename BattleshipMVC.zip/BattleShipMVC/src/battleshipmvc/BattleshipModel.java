package battleshipmvc;

/**
 * @author Stephen Bondurich Dec 3, 2018
 *
 *         The model for a game of battleship.
 * 
 */
public class BattleshipModel {

	private final int BOARD_SIZE = 10;
	private int totalShips;
	private Boardspace[][] gameBoard = new Boardspace[BOARD_SIZE][BOARD_SIZE];

	public BattleshipModel() {
		createNewGame();
	}

	public void createNewGame() {
		fillBoard();
		totalShips = 0;
	}

	private void fillBoard() {
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				gameBoard[i][j] = new Boardspace();
			}
		}
	}

	public Boardspace getBoardspace(int row, int col) {
		return gameBoard[row][col];
	}

	public int getBoardSize() {
		return this.BOARD_SIZE;
	}

	public void selectSpace(int row, int col) {
		if (gameBoard[row][col].isAlreadySelected() == false) {
			gameBoard[row][col].setSelected();
			if (gameBoard[row][col].isShip() == true) {
				totalShips--;
			}

		} else {
			System.out.println("Space already taken!");
			// for debugging
		}
	}

	public boolean canShipBeInserted(int row1, int col1, int row2, int col2) {
		if (row1 == row2) {

			if (col1 > col2) {
				int temp = col1;
				col1 = col2;
				col2 = temp;
			}

			// first we cheeck to make sure that all the spaces are available
			for (int i = col1; i <= col2; i++) {
				if (gameBoard[row1][i].isShip()) {
					return false;
				}
			}

		}

		else if (col1 == col2) {

			if (row1 > row2) {
				int temp = row1;
				row1 = row2;
				row2 = temp;
			}

			for (int i = row1; i <= row2; i++) {
				if (gameBoard[i][col1].isShip()) {
					return false;
				}
			}

		}

		return true;
		// I need not worry about diagonals because this method only gets called once it
		// has been determined it's not a diagonal
		// also, I cannot substitute this in method below bc the exception type matters;
		// not just t/f

	}

	public void addShip(int row1, int col1, int row2, int col2) throws Exception {
		if (row1 == row2) {

			if (col1 > col2) {
				int temp = col1;
				col1 = col2;
				col2 = temp;
			}

			// first we check to make sure that all the spaces are available
			for (int i = col1; i <= col2; i++) {
				if (gameBoard[row1][i].isShip()) {
					Exception e = new Exception("No overlap allowed!");
					throw e;
				}
			}
			// then we go ahead and add them
			for (int i = col1; i <= col2; i++) {
				gameBoard[row1][i].setShip(true);
				totalShips++;
			}
		}

		else if (col1 == col2) {

			if (row1 > row2) {
				int temp = row1;
				row1 = row2;
				row2 = temp;
			}

			for (int i = row1; i <= row2; i++) {
				if (gameBoard[i][col1].isShip()) {
					Exception e = new Exception("No overlap allowed!");
					throw e;
				}
			}

			for (int i = row1; i <= row2; i++) {
				gameBoard[i][col1].setShip(true);
				totalShips++;
			}

		} else {
			System.out.println("Invalid ship");
			throw new Exception("No diagonals");
		}
	}// turns all spaces between the first coordinate and second coordinate into ship
		// spaces, assuming a linear path

	public int getTotalShips() {
		return this.totalShips;
	}

	public boolean isGameOver() {
		if (totalShips == 0)
			return true;
		else
			return false;
	}

}
